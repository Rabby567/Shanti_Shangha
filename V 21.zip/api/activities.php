<?php
/**
 * Activities API.
 *
 * Public:
 *   GET /api/activities.php?action=list
 *   GET /api/activities.php?action=one&id=123
 *
 * Admin:
 *   GET    /api/activities.php?action=admin-list
 *   POST   /api/activities.php?action=create
 *   POST   /api/activities.php?action=update
 *   POST   /api/activities.php?action=delete
 *
 * Activity images are stored as paths in activity_images.
 * Actual files will be handled by the hosting upload system later.
 */

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';
allow_cors();

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    send_json(['success' => false, 'message' => 'Server configuration is missing.'], 503);
}

$config = require $configFile;
$sessionName = $config['app']['session_name'] ?? 'shanti_sangha_admin';

session_name($sessionName);
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

function require_admin(): void
{
    if (empty($_SESSION['admin_id'])) {
        send_json(['success' => false, 'message' => 'Authentication required.'], 401);
    }
}

function make_slug(string $title): string
{
    $slug = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $title), '-'));
    return $slug !== '' ? $slug : 'activity';
}

function unique_slug(PDO $pdo, string $title, ?int $ignoreId = null): string
{
    $base = make_slug($title);
    $slug = $base;
    $counter = 2;

    while (true) {
        $sql = 'SELECT id FROM activities WHERE slug = :slug';
        $params = ['slug' => $slug];

        if ($ignoreId !== null) {
            $sql .= ' AND id != :id';
            $params['id'] = $ignoreId;
        }

        $statement = $pdo->prepare($sql . ' LIMIT 1');
        $statement->execute($params);

        if (!$statement->fetch()) {
            return $slug;
        }

        $slug = $base . '-' . $counter++;
    }
}

function normalize_activity(PDO $pdo, array $row): array
{
    $statement = $pdo->prepare(
        'SELECT id, file_path, caption, sort_order
         FROM activity_images
         WHERE activity_id = :activity_id
         ORDER BY sort_order ASC, id ASC'
    );
    $statement->execute(['activity_id' => $row['id']]);

    $photos = [];
    foreach ($statement->fetchAll() as $photo) {
        $photos[] = [
            'id' => (int) $photo['id'],
            'file_path' => (string) $photo['file_path'],
            'caption' => (string) ($photo['caption'] ?? ''),
            'sort_order' => (int) $photo['sort_order'],
        ];
    }

    return [
        'id' => (int) $row['id'],
        'title' => (string) $row['title'],
        'slug' => (string) $row['slug'],
        'short_description' => (string) ($row['short_description'] ?? ''),
        'description' => (string) ($row['description'] ?? ''),
        'event_date' => $row['event_date'],
        'location' => (string) ($row['location'] ?? ''),
        'cover_image' => (string) ($row['cover_image'] ?? ''),
        'is_published' => (bool) $row['is_published'],
        'sort_order' => (int) $row['sort_order'],
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at'],
        'photos' => $photos,
    ];
}

function read_payload(): array
{
    $payload = json_decode(file_get_contents('php://input'), true);

    if (!is_array($payload)) {
        send_json(['success' => false, 'message' => 'Invalid JSON request.'], 422);
    }

    return $payload;
}

function save_activity_images(PDO $pdo, int $activityId, array $photos): void
{
    $pdo->prepare('DELETE FROM activity_images WHERE activity_id = :activity_id')
        ->execute(['activity_id' => $activityId]);

    $statement = $pdo->prepare(
        'INSERT INTO activity_images (activity_id, file_path, caption, sort_order)
         VALUES (:activity_id, :file_path, :caption, :sort_order)'
    );

    foreach ($photos as $index => $photo) {
        if (is_string($photo)) {
            $path = trim($photo);
            $caption = '';
        } elseif (is_array($photo)) {
            $path = trim((string) ($photo['file_path'] ?? ''));
            $caption = trim((string) ($photo['caption'] ?? ''));
        } else {
            continue;
        }

        if ($path === '') {
            continue;
        }

        $statement->execute([
            'activity_id' => $activityId,
            'file_path' => $path,
            'caption' => $caption,
            'sort_order' => $index,
        ]);
    }
}

$action = $_GET['action'] ?? 'list';

try {
    $pdo = db();

    if ($action === 'list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $statement = $pdo->query(
            'SELECT * FROM activities
             WHERE is_published = 1
             ORDER BY sort_order ASC, event_date DESC, id DESC'
        );

        $activities = array_map(
            fn(array $row): array => normalize_activity($pdo, $row),
            $statement->fetchAll()
        );

        send_json(['success' => true, 'activities' => $activities]);
    }

    if ($action === 'one' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        $slug = trim((string) ($_GET['slug'] ?? ''));

        if ($id > 0) {
            $statement = $pdo->prepare('SELECT * FROM activities WHERE id = :id LIMIT 1');
            $statement->execute(['id' => $id]);
        } elseif ($slug !== '') {
            $statement = $pdo->prepare('SELECT * FROM activities WHERE slug = :slug LIMIT 1');
            $statement->execute(['slug' => $slug]);
        } else {
            send_json(['success' => false, 'message' => 'Activity identifier is required.'], 422);
        }

        $row = $statement->fetch();

        if (!$row || (!(bool) $row['is_published'] && empty($_SESSION['admin_id']))) {
            send_json(['success' => false, 'message' => 'Activity not found.'], 404);
        }

        send_json(['success' => true, 'activity' => normalize_activity($pdo, $row)]);
    }

    require_admin();

    if ($action === 'admin-list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $statement = $pdo->query(
            'SELECT * FROM activities
             ORDER BY sort_order ASC, event_date DESC, id DESC'
        );

        $activities = array_map(
            fn(array $row): array => normalize_activity($pdo, $row),
            $statement->fetchAll()
        );

        send_json(['success' => true, 'activities' => $activities]);
    }

    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $payload = read_payload();

        $title = trim((string) ($payload['title'] ?? ''));
        if ($title === '') {
            send_json(['success' => false, 'message' => 'কার্যক্রমের নাম দিন।'], 422);
        }

        $slug = unique_slug($pdo, $title);

        $statement = $pdo->prepare(
            'INSERT INTO activities
                (title, slug, short_description, description, event_date, location,
                 cover_image, is_published, sort_order)
             VALUES
                (:title, :slug, :short_description, :description, :event_date, :location,
                 :cover_image, :is_published, :sort_order)'
        );

        $statement->execute([
            'title' => $title,
            'slug' => $slug,
            'short_description' => trim((string) ($payload['short_description'] ?? '')),
            'description' => trim((string) ($payload['description'] ?? '')),
            'event_date' => (($value = trim((string) ($payload['event_date'] ?? ''))) !== '') ? $value : null,
            'location' => trim((string) ($payload['location'] ?? '')),
            'cover_image' => trim((string) ($payload['cover_image'] ?? '')),
            'is_published' => !empty($payload['is_published']) ? 1 : 0,
            'sort_order' => (int) ($payload['sort_order'] ?? 0),
        ]);

        $activityId = (int) $pdo->lastInsertId();
        save_activity_images($pdo, $activityId, (array) ($payload['photos'] ?? []));

        $created = $pdo->prepare('SELECT * FROM activities WHERE id = :id');
        $created->execute(['id' => $activityId]);

        send_json([
            'success' => true,
            'message' => 'কার্যক্রম সফলভাবে যোগ হয়েছে।',
            'activity' => normalize_activity($pdo, $created->fetch()),
        ], 201);
    }

    if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $payload = read_payload();
        $id = (int) ($payload['id'] ?? 0);

        if ($id < 1) {
            send_json(['success' => false, 'message' => 'কার্যক্রমের ID প্রয়োজন।'], 422);
        }

        $title = trim((string) ($payload['title'] ?? ''));
        if ($title === '') {
            send_json(['success' => false, 'message' => 'কার্যক্রমের নাম দিন।'], 422);
        }

        $exists = $pdo->prepare('SELECT id FROM activities WHERE id = :id LIMIT 1');
        $exists->execute(['id' => $id]);

        if (!$exists->fetch()) {
            send_json(['success' => false, 'message' => 'কার্যক্রমটি পাওয়া যায়নি।'], 404);
        }

        $slug = unique_slug($pdo, $title, $id);

        $statement = $pdo->prepare(
            'UPDATE activities SET
                title = :title,
                slug = :slug,
                short_description = :short_description,
                description = :description,
                event_date = :event_date,
                location = :location,
                cover_image = :cover_image,
                is_published = :is_published,
                sort_order = :sort_order
             WHERE id = :id'
        );

        $statement->execute([
            'id' => $id,
            'title' => $title,
            'slug' => $slug,
            'short_description' => trim((string) ($payload['short_description'] ?? '')),
            'description' => trim((string) ($payload['description'] ?? '')),
            'event_date' => (($value = trim((string) ($payload['event_date'] ?? ''))) !== '') ? $value : null,
            'location' => trim((string) ($payload['location'] ?? '')),
            'cover_image' => trim((string) ($payload['cover_image'] ?? '')),
            'is_published' => !empty($payload['is_published']) ? 1 : 0,
            'sort_order' => (int) ($payload['sort_order'] ?? 0),
        ]);

        save_activity_images($pdo, $id, (array) ($payload['photos'] ?? []));

        $updated = $pdo->prepare('SELECT * FROM activities WHERE id = :id');
        $updated->execute(['id' => $id]);

        send_json([
            'success' => true,
            'message' => 'কার্যক্রম সফলভাবে আপডেট হয়েছে।',
            'activity' => normalize_activity($pdo, $updated->fetch()),
        ]);
    }

    if ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $payload = read_payload();
        $id = (int) ($payload['id'] ?? 0);

        if ($id < 1) {
            send_json(['success' => false, 'message' => 'কার্যক্রমের ID প্রয়োজন।'], 422);
        }

        $statement = $pdo->prepare('DELETE FROM activities WHERE id = :id');
        $statement->execute(['id' => $id]);

        if ($statement->rowCount() === 0) {
            send_json(['success' => false, 'message' => 'কার্যক্রমটি পাওয়া যায়নি।'], 404);
        }

        send_json([
            'success' => true,
            'message' => 'কার্যক্রম মুছে ফেলা হয়েছে।',
        ]);
    }

    send_json(['success' => false, 'message' => 'Invalid activities request.'], 405);
} catch (Throwable $error) {
    send_json([
        'success' => false,
        'message' => 'কার্যক্রমের তথ্য সংরক্ষণ করা যায়নি।',
    ], 503);
}
