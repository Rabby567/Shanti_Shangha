import { useEffect, useMemo, useState } from "react";

type ActivityRecord = {
  id: number;
  title: string;
  slug: string;
  short_description: string;
  description: string;
  event_date: string | null;
  location: string;
  cover_image: string;
  is_published: boolean;
  sort_order: number;
  photos: Array<{
    id: number;
    file_path: string;
    caption: string;
    sort_order: number;
  }>;
};

type ActivityForm = {
  id?: number;
  title: string;
  short_description: string;
  description: string;
  event_date: string;
  location: string;
  cover_image: string;
  is_published: boolean;
  sort_order: number;
  photos: string;
};

const emptyForm: ActivityForm = {
  title: "",
  short_description: "",
  description: "",
  event_date: "",
  location: "",
  cover_image: "/images/activity-1.svg",
  is_published: true,
  sort_order: 0,
  photos: "",
};

function recordToForm(activity: ActivityRecord): ActivityForm {
  return {
    id: activity.id,
    title: activity.title,
    short_description: activity.short_description,
    description: activity.description,
    event_date: activity.event_date || "",
    location: activity.location,
    cover_image: activity.cover_image,
    is_published: activity.is_published,
    sort_order: activity.sort_order,
    photos: activity.photos.map((photo) => photo.file_path).join("\n"),
  };
}

function formToPayload(form: ActivityForm) {
  return {
    ...(form.id ? { id: form.id } : {}),
    title: form.title,
    short_description: form.short_description,
    description: form.description,
    event_date: form.event_date,
    location: form.location,
    cover_image: form.cover_image,
    is_published: form.is_published,
    sort_order: form.sort_order,
    photos: form.photos
      .split("\n")
      .map((path) => path.trim())
      .filter(Boolean),
  };
}

export function ActivitiesManagement() {
  const [activities, setActivities] = useState<ActivityRecord[]>([]);
  const [form, setForm] = useState<ActivityForm>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const isEditing = useMemo(() => Boolean(form.id), [form.id]);

  const loadActivities = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/activities.php?action=admin-list", {
        credentials: "include",
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "কার্যক্রম লোড করা যায়নি।");
      }

      setActivities(data.activities);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "কার্যক্রম লোড করা যায়নি।");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
  }, []);

  const updateField = <K extends keyof ActivityForm>(key: K, value: ActivityForm[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
    setMessage("");
    setError("");
  };

  const resetForm = () => {
    setForm(emptyForm);
    setMessage("");
    setError("");
  };

  const handleSave = async () => {
    if (!form.title.trim()) {
      setError("কার্যক্রমের নাম দিতে হবে।");
      return;
    }

    try {
      setSaving(true);
      setMessage("");
      setError("");

      const action = isEditing ? "update" : "create";
      const response = await fetch(`/api/activities.php?action=${action}`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formToPayload(form)),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "সংরক্ষণ করা যায়নি।");
      }

      setMessage(data.message);
      resetForm();
      await loadActivities();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "সংরক্ষণ করা যায়নি।");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("এই কার্যক্রমটি স্থায়ীভাবে মুছে ফেলতে চান?")) return;

    try {
      setDeletingId(id);
      setError("");
      setMessage("");

      const response = await fetch("/api/activities.php?action=delete", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "মুছে ফেলা যায়নি।");
      }

      setMessage(data.message);
      if (form.id === id) resetForm();
      await loadActivities();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "মুছে ফেলা যায়নি।");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <section className="admin-activities-module">
      <div className="admin-module-header">
        <div>
          <span className="admin-kicker">CONTENT MANAGEMENT</span>
          <h1>কার্যক্রম পরিচালনা</h1>
          <p>নতুন কার্যক্রম যোগ করুন এবং প্রকাশিত কার্যক্রম সম্পাদনা করুন।</p>
        </div>
        <button type="button" className="admin-primary-button" onClick={resetForm}>
          ＋ নতুন কার্যক্রম
        </button>
      </div>

      {message && <div className="admin-success-notice">✓ {message}</div>}
      {error && <div className="admin-data-notice">{error}</div>}

      <div className="admin-activities-layout">
        <div className="admin-form-card">
          <div className="admin-form-section-heading">
            <span className="admin-kicker">{isEditing ? "EDIT ACTIVITY" : "NEW ACTIVITY"}</span>
            <h2>{isEditing ? "কার্যক্রম সম্পাদনা" : "নতুন কার্যক্রম যোগ করুন"}</h2>
          </div>

          <div className="admin-form-grid">
            <label className="full">
              <span>কার্যক্রমের নাম *</span>
              <input value={form.title} onChange={(e) => updateField("title", e.target.value)} />
            </label>

            <label className="full">
              <span>সংক্ষিপ্ত description</span>
              <textarea rows={3} value={form.short_description} onChange={(e) => updateField("short_description", e.target.value)} />
            </label>

            <label className="full">
              <span>বিস্তারিত description</span>
              <textarea rows={7} value={form.description} onChange={(e) => updateField("description", e.target.value)} />
            </label>

            <label>
              <span>তারিখ</span>
              <input type="date" value={form.event_date} onChange={(e) => updateField("event_date", e.target.value)} />
            </label>

            <label>
              <span>স্থান</span>
              <input value={form.location} onChange={(e) => updateField("location", e.target.value)} />
            </label>

            <label className="full">
              <span>Cover image path / URL</span>
              <input value={form.cover_image} onChange={(e) => updateField("cover_image", e.target.value)} placeholder="/uploads/activities/cover.jpg" />
            </label>

            <label className="full">
              <span>কার্যক্রমের ছবি — প্রতি লাইনে একটি path/URL</span>
              <textarea
                rows={5}
                value={form.photos}
                onChange={(e) => updateField("photos", e.target.value)}
                placeholder={"/uploads/activities/photo-1.jpg\n/uploads/activities/photo-2.jpg"}
              />
            </label>

            <label>
              <span>ক্রম</span>
              <input type="number" min="0" value={form.sort_order} onChange={(e) => updateField("sort_order", Number(e.target.value))} />
            </label>

            <label className="admin-checkbox-field">
              <input type="checkbox" checked={form.is_published} onChange={(e) => updateField("is_published", e.target.checked)} />
              <span>Public website-এ প্রকাশিত থাকবে</span>
            </label>
          </div>

          <div className="admin-form-actions">
            {isEditing && (
              <button type="button" className="admin-secondary-button" onClick={resetForm}>
                বাতিল
              </button>
            )}
            <button type="button" className="admin-primary-button" disabled={saving} onClick={handleSave}>
              {saving ? "সংরক্ষণ হচ্ছে..." : isEditing ? "পরিবর্তন সংরক্ষণ করুন" : "কার্যক্রম যোগ করুন"}
            </button>
          </div>
        </div>

        <div className="admin-form-card admin-activity-list-card">
          <div className="admin-form-section-heading">
            <span className="admin-kicker">ACTIVITY LIST</span>
            <h2>সব কার্যক্রম</h2>
          </div>

          {loading ? (
            <div className="admin-list-empty">কার্যক্রম লোড হচ্ছে...</div>
          ) : activities.length === 0 ? (
            <div className="admin-list-empty">এখনও কোনো কার্যক্রম যোগ করা হয়নি।</div>
          ) : (
            <div className="admin-activity-list">
              {activities.map((activity) => (
                <article className="admin-activity-item" key={activity.id}>
                  <img src={activity.cover_image || "/images/activity-1.svg"} alt="" />
                  <div className="admin-activity-item-content">
                    <div className="admin-activity-item-top">
                      <strong>{activity.title}</strong>
                      <span className={activity.is_published ? "is-published" : "is-draft"}>
                        {activity.is_published ? "প্রকাশিত" : "Draft"}
                      </span>
                    </div>
                    <p>{activity.short_description || "কোনো সংক্ষিপ্ত description নেই।"}</p>
                    <small>
                      {activity.event_date || "তারিখ নেই"} {activity.location ? `• ${activity.location}` : ""}
                    </small>
                    <div className="admin-activity-actions">
                      <button type="button" onClick={() => setForm(recordToForm(activity))}>সম্পাদনা</button>
                      <button type="button" className="danger" disabled={deletingId === activity.id} onClick={() => handleDelete(activity.id)}>
                        {deletingId === activity.id ? "মুছছে..." : "মুছে ফেলুন"}
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
