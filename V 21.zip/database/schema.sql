-- ================================================================
-- Shanti Sangha - MySQL database foundation
-- Compatible with MySQL 8+ / MariaDB 10.5+
-- ================================================================

CREATE DATABASE IF NOT EXISTS shanti_sangha
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE shanti_sangha;

-- ---------------------------------------------------------------
-- Admin users
-- Passwords are stored as PHP password_hash() values, never plain text.
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(30) NULL,
    avatar_path VARCHAR(500) NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'admin') NOT NULL DEFAULT 'admin',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    auth_version INT UNSIGNED NOT NULL DEFAULT 1,
    last_login_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Login protection audit
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(190) NOT NULL,
    ip_address VARCHAR(64) NULL,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    was_successful TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_login_email_time (email, attempted_at),
    INDEX idx_login_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Activities
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activities (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    short_description TEXT NULL,
    description LONGTEXT NULL,
    event_date DATE NULL,
    location VARCHAR(255) NULL,
    cover_image VARCHAR(500) NULL,
    is_published TINYINT(1) NOT NULL DEFAULT 0,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_activities_published (is_published),
    INDEX idx_activities_date (event_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activity_images (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    activity_id BIGINT UNSIGNED NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    caption VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_activity_images_activity
        FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE,
    INDEX idx_activity_images_activity (activity_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Gallery: image/video metadata. Actual files live in /uploads/.
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gallery (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NULL,
    caption TEXT NULL,
    media_type ENUM('image', 'video') NOT NULL DEFAULT 'image',
    file_path VARCHAR(500) NOT NULL,
    thumbnail_path VARCHAR(500) NULL,
    category VARCHAR(120) NULL,
    is_published TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_gallery_type (media_type),
    INDEX idx_gallery_published (is_published)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- About page accordion/content blocks
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS about_sections (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description LONGTEXT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_published TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Homepage content/settings
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS homepage_content (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_key VARCHAR(120) NOT NULL UNIQUE,
    content_value LONGTEXT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Blood requests
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS blood_requests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(160) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    contact_phone VARCHAR(30) NOT NULL,
    hospital VARCHAR(255) NULL,
    location VARCHAR(255) NULL,
    required_date DATE NULL,
    units_needed TINYINT UNSIGNED NOT NULL DEFAULT 1,
    details TEXT NULL,
    status ENUM('pending', 'approved', 'fulfilled', 'cancelled') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_blood_requests_group (blood_group),
    INDEX idx_blood_requests_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Registered blood donors
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS blood_donors (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    area VARCHAR(255) NULL,
    last_donation_date DATE NULL,
    availability ENUM('available', 'unavailable') NOT NULL DEFAULT 'available',
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_donors_group_status (blood_group, status),
    INDEX idx_donors_area (area),
    INDEX idx_donors_availability (availability)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Membership applications
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS membership_applications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    email VARCHAR(190) NULL,
    address VARCHAR(500) NULL,
    father_name VARCHAR(160) NULL,
    mother_name VARCHAR(160) NULL,
    profession VARCHAR(160) NULL,
    blood_group VARCHAR(5) NULL,
    message TEXT NULL,
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_members_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- General site settings
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(120) NOT NULL UNIQUE,
    setting_value LONGTEXT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO site_settings (setting_key, setting_value) VALUES
('site_name', 'শান্তি সংঘ'),
('site_tagline', 'যুব সমাজ কল্যাণ পরিষদ'),
('site_logo_path', '/images/logo.svg'),
('site_favicon_path', '/images/logo.svg'),
('site_contact_phone', ''),
('site_contact_email', 'admin@shantishangha.org'),
('site_address', ''),
('site_facebook_url', ''),
('site_status', 'active'),
('homepage_hero_title_line1', 'এসো শান্তি সংঘ করি,'),
('homepage_hero_title_line2', 'মানবতার সেবা করি'),
('homepage_hero_subtitle', 'অসহায় মানুষের পাশে দাঁড়ানো, রক্তদান, বৃক্ষরোপণ, শীতবস্ত্র বিতরণ এবং বিভিন্ন মানবিক কার্যক্রমের মাধ্যমে একটি সুন্দর ও মানবিক সমাজ গড়ে তোলাই আমাদের লক্ষ্য।'),
('homepage_hero_image', ''),
('homepage_about_enabled', '1'),
('homepage_activities_enabled', '1'),
('homepage_gallery_enabled', '1'),
('homepage_blood_enabled', '1'),
('homepage_statistics_enabled', '1'),
('security_session_timeout', '120'),
('security_login_protection', '1'),
('security_failed_login_limit', '5'),
('upload_max_size_mb', '8'),
('upload_allowed_formats', 'jpg,png,webp,gif'),
('upload_directory', '/uploads'),
('upload_optimization_enabled', '0'),
('notify_blood_request', '1'),
('notify_member_application', '1'),
('notify_activity', '1'),
('notify_email_enabled', '0')
ON DUPLICATE KEY UPDATE setting_value = setting_value;

