<?php
/**
 * One-time admin bootstrap utility.
 *
 * IMPORTANT: Run this only during initial server setup, then DELETE this file.
 * The setup token is configured in api/config.php and is never committed.
 */

require_once __DIR__ . '/helpers.php';
allow_cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(['success' => false, 'message' => 'POST required.'], 405);
}

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    send_json(['success' => false, 'message' => 'Server configuration is missing.'], 503);
}

$config = require $configFile;
$setupToken = (string) ($config['app']['setup_token'] ?? '');
$providedToken = (string) ($_SERVER['HTTP_X_SETUP_TOKEN'] ?? '');

if ($setupToken === '' || !hash_equals($setupToken, $providedToken)) {
    send_json(['success' => false, 'message' => 'Unauthorized.'], 403);
}

$payload = json_decode(file_get_contents('php://input'), true);
$name = trim((string) ($payload['name'] ?? ''));
$email = trim((string) ($payload['email'] ?? ''));
$password = (string) ($payload['password'] ?? '');

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
    send_json(['success' => false, 'message' => 'Name, valid email and an 8+ character password are required.'], 422);
}

try {
    require_once __DIR__ . '/db.php';

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $statement = db()->prepare(
        'INSERT INTO admins (name, email, password_hash, role)
         VALUES (:name, :email, :password_hash, :role)'
    );
    $statement->execute([
        'name' => $name,
        'email' => $email,
        'password_hash' => $passwordHash,
        'role' => 'super_admin',
    ]);

    send_json(['success' => true, 'message' => 'Admin created successfully. Delete create-admin.php now.']);
} catch (Throwable $error) {
    send_json(['success' => false, 'message' => 'Admin could not be created.'], 409);
}
