import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import type { AdminUser } from "../types";

const roleLabel: Record<AdminUser["role"], string> = {
  super_admin: "Super Admin",
  admin: "Admin",
};

const avatarUrl = (path: string | null) => path || "";

function initials(name: string) {
  return name.trim().slice(0, 1).toUpperCase() || "A";
}

export function SettingsManagement() {
  const [me, setMe] = useState<AdminUser | null>(null);
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [adminsLoading, setAdminsLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [avatarPreview, setAvatarPreview] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [removeAvatar, setRemoveAvatar] = useState(false);
  const [profileForm, setProfileForm] = useState({ name: "", email: "", phone: "" });
  const [passwordForm, setPasswordForm] = useState({
    current_password: "",
    new_password: "",
    confirm_password: "",
  });
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);
  const [adminForm, setAdminForm] = useState({
    name: "",
    email: "",
    phone: "",
    role: "admin" as AdminUser["role"],
    is_active: true,
    password: "",
    avatar: null as File | null,
    remove_avatar: false,
  });
  const fileRef = useRef<HTMLInputElement>(null);

  const isSuperAdmin = me?.role === "super_admin";

  const flash = (message: string) => {
    setNotice(message);
    setError("");
    window.setTimeout(() => setNotice(""), 3200);
  };

  const loadMe = async () => {
    const response = await fetch("/api/auth.php?action=me", { credentials: "include" });
    const data = await response.json();
    if (!response.ok || !data.success || !data.authenticated) {
      throw new Error(data.message || "Admin information পাওয়া যায়নি।");
    }

    const admin = data.admin as AdminUser;
    setMe(admin);
    setProfileForm({
      name: admin.name,
      email: admin.email,
      phone: admin.phone || "",
    });
    setAvatarPreview(avatarUrl(admin.avatar_path));
    setRemoveAvatar(false);
  };

  const loadAdmins = async () => {
    if (!isSuperAdmin) return;
    setAdminsLoading(true);
    try {
      const response = await fetch("/api/admins.php?action=list", { credentials: "include" });
      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.message || "Admin list পাওয়া যায়নি।");
      }
      setAdmins(data.admins);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Admin list load করা যায়নি।");
    } finally {
      setAdminsLoading(false);
    }
  };

  useEffect(() => {
    loadMe()
      .catch((e) => setError(e instanceof Error ? e.message : "Settings load করা যায়নি।"))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (isSuperAdmin) loadAdmins();
  }, [isSuperAdmin]);

  useEffect(() => {
    return () => {
      if (avatarPreview.startsWith("blob:")) URL.revokeObjectURL(avatarPreview);
    };
  }, [avatarPreview]);

  const activeAdminCount = useMemo(
    () => admins.filter((admin) => admin.is_active).length,
    [admins]
  );

  const handleAvatarChange = (file: File | undefined) => {
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setError("শুধু JPG, PNG অথবা WEBP image ব্যবহার করুন।");
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      setError("Profile image সর্বোচ্চ 3MB হতে পারবে।");
      return;
    }

    if (avatarPreview.startsWith("blob:")) URL.revokeObjectURL(avatarPreview);
    setAvatarFile(file);
    setAvatarPreview(URL.createObjectURL(file));
    setRemoveAvatar(false);
    setError("");
  };

  const saveProfile = async (event: FormEvent) => {
    event.preventDefault();
    setSavingProfile(true);
    setError("");
    setNotice("");

    try {
      const body = new FormData();
      body.append("name", profileForm.name);
      body.append("email", profileForm.email);
      body.append("phone", profileForm.phone);
      body.append("remove_avatar", removeAvatar ? "1" : "0");
      if (avatarFile) body.append("avatar", avatarFile);

      const response = await fetch("/api/auth.php?action=profile", {
        method: "POST",
        credentials: "include",
        body,
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Profile save করা যায়নি।");
      }

      setMe(data.admin);
      window.dispatchEvent(new CustomEvent("admin-profile-updated", { detail: data.admin }));
      setProfileForm({
        name: data.admin.name,
        email: data.admin.email,
        phone: data.admin.phone || "",
      });
      setAvatarFile(null);
      setAvatarPreview(avatarUrl(data.admin.avatar_path));
      setRemoveAvatar(false);
      if (fileRef.current) fileRef.current.value = "";
      flash("Profile সফলভাবে আপডেট হয়েছে।");
      if (isSuperAdmin) loadAdmins();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Profile save করা যায়নি।");
    } finally {
      setSavingProfile(false);
    }
  };

  const savePassword = async (event: FormEvent) => {
    event.preventDefault();
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      setError("New password এবং confirm password একই হতে হবে।");
      return;
    }

    setSavingPassword(true);
    setError("");
    setNotice("");

    try {
      const response = await fetch("/api/auth.php?action=password", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current_password: passwordForm.current_password,
          new_password: passwordForm.new_password,
        }),
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Password পরিবর্তন করা যায়নি।");
      }

      setPasswordForm({ current_password: "", new_password: "", confirm_password: "" });
      flash("Password সফলভাবে পরিবর্তন হয়েছে।");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Password পরিবর্তন করা যায়নি।");
    } finally {
      setSavingPassword(false);
    }
  };

  const openCreate = () => {
    setEditingAdmin(null);
    setAdminForm({
      name: "",
      email: "",
      phone: "",
      role: "admin",
      is_active: true,
      password: "",
      avatar: null,
      remove_avatar: false,
    });
    setModalOpen(true);
    setError("");
  };

  const openEdit = (admin: AdminUser) => {
    setEditingAdmin(admin);
    setAdminForm({
      name: admin.name,
      email: admin.email,
      phone: admin.phone || "",
      role: admin.role,
      is_active: admin.is_active,
      password: "",
      avatar: null,
      remove_avatar: false,
    });
    setModalOpen(true);
    setError("");
  };

  const saveAdmin = async (event: FormEvent) => {
    event.preventDefault();
    setError("");

    try {
      if (!editingAdmin && adminForm.password.length < 8) {
        throw new Error("নতুন admin-এর password কমপক্ষে 8 characters হতে হবে।");
      }

      const body = new FormData();
      body.append("name", adminForm.name);
      body.append("email", adminForm.email);
      body.append("phone", adminForm.phone);
      body.append("role", adminForm.role);
      body.append("is_active", adminForm.is_active ? "1" : "0");
      body.append("remove_avatar", adminForm.remove_avatar ? "1" : "0");
      if (adminForm.avatar) body.append("avatar", adminForm.avatar);

      let action = "create";
      if (editingAdmin) {
        action = "update";
        body.append("id", String(editingAdmin.id));
      } else {
        body.append("password", adminForm.password);
      }

      const response = await fetch(`/api/admins.php?action=${action}`, {
        method: "POST",
        credentials: "include",
        body,
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Admin save করা যায়নি।");
      }

      setModalOpen(false);
      flash(data.message);
      await loadAdmins();
      await loadMe();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Admin save করা যায়নি।");
    }
  };

  const deleteAdmin = async (admin: AdminUser) => {
    if (!window.confirm(`"${admin.name}" admin account কি delete করতে চান?`)) return;

    setError("");
    try {
      const response = await fetch("/api/admins.php?action=delete", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: admin.id }),
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Admin delete করা যায়নি।");
      }

      flash(data.message);
      await loadAdmins();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Admin delete করা যায়নি।");
    }
  };

  if (loading) {
    return (
      <section className="admin-module">
        <div className="admin-form-card admin-settings-loading">Settings প্রস্তুত হচ্ছে...</div>
      </section>
    );
  }

  return (
    <section className="admin-module admin-settings-module">
      <div className="admin-module-header">
        <div>
          <span className="admin-kicker">CONFIGURATION</span>
          <h1>সেটিংস</h1>
          <p>Admin account, profile এবং access management এখান থেকে পরিচালনা করুন।</p>
        </div>
      </div>

      {notice && <div className="admin-success-notice">{notice}</div>}
      {error && <div className="admin-login-error admin-settings-error">{error}</div>}

      <div className="admin-settings-grid">
        <form className="admin-form-card admin-profile-card" onSubmit={saveProfile}>
          <div className="admin-form-section-heading">
            <span className="admin-kicker">MY PROFILE</span>
            <h2>Admin Profile</h2>
            <p>আপনার নাম, ছবি, phone এবং login email আপডেট করুন।</p>
          </div>

          <div className="admin-profile-editor">
            <div className="admin-avatar-editor">
              {avatarPreview ? (
                <img src={avatarPreview} alt={me?.name || "Admin"} />
              ) : (
                <span>{initials(me?.name || "A")}</span>
              )}
              <button type="button" onClick={() => fileRef.current?.click()}>
                ছবি পরিবর্তন
              </button>
              {(avatarPreview || me?.avatar_path) && (
                <button
                  className="admin-avatar-remove"
                  type="button"
                  onClick={() => {
                    if (avatarPreview.startsWith("blob:")) URL.revokeObjectURL(avatarPreview);
                    setAvatarFile(null);
                    setAvatarPreview("");
                    setRemoveAvatar(true);
                    if (fileRef.current) fileRef.current.value = "";
                  }}
                >
                  ছবি সরান
                </button>
              )}
              <input
                ref={fileRef}
                hidden
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(event) => handleAvatarChange(event.target.files?.[0])}
              />
              <small>JPG / PNG / WEBP · সর্বোচ্চ 3MB</small>
            </div>

            <div className="admin-form-grid">
              <label>
                Admin Name *
                <input
                  value={profileForm.name}
                  onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                  required
                />
              </label>
              <label>
                Phone Number
                <input
                  type="tel"
                  value={profileForm.phone}
                  onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                  placeholder="01XXXXXXXXX"
                />
              </label>
              <label className="full">
                Email *
                <input
                  type="email"
                  value={profileForm.email}
                  onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                  required
                />
              </label>
            </div>
          </div>

          <div className="admin-form-actions">
            <button className="admin-primary-button" type="submit" disabled={savingProfile}>
              {savingProfile ? "সংরক্ষণ হচ্ছে..." : "Profile Save করুন"}
            </button>
          </div>
        </form>

        <form className="admin-form-card" onSubmit={savePassword}>
          <div className="admin-form-section-heading">
            <span className="admin-kicker">SECURITY</span>
            <h2>Password পরিবর্তন</h2>
            <p>নিরাপত্তার জন্য নিয়মিত শক্তিশালী password ব্যবহার করুন।</p>
          </div>

          <div className="admin-form-grid admin-password-grid">
            <label className="full">
              Current Password *
              <input
                type="password"
                autoComplete="current-password"
                value={passwordForm.current_password}
                onChange={(e) =>
                  setPasswordForm({ ...passwordForm, current_password: e.target.value })
                }
                required
              />
            </label>
            <label>
              New Password *
              <input
                type="password"
                autoComplete="new-password"
                minLength={8}
                value={passwordForm.new_password}
                onChange={(e) =>
                  setPasswordForm({ ...passwordForm, new_password: e.target.value })
                }
                required
              />
            </label>
            <label>
              Confirm Password *
              <input
                type="password"
                autoComplete="new-password"
                minLength={8}
                value={passwordForm.confirm_password}
                onChange={(e) =>
                  setPasswordForm({ ...passwordForm, confirm_password: e.target.value })
                }
                required
              />
            </label>
          </div>

          <div className="admin-form-actions">
            <button className="admin-primary-button" type="submit" disabled={savingPassword}>
              {savingPassword ? "পরিবর্তন হচ্ছে..." : "Password Change করুন"}
            </button>
          </div>
        </form>
      </div>

      {isSuperAdmin && (
        <div className="admin-form-card admin-admins-card">
          <div className="admin-admins-heading">
            <div>
              <span className="admin-kicker">ACCESS MANAGEMENT</span>
              <h2>Admin Management</h2>
              <p>একাধিক Admin account তৈরি, edit, activate/deactivate এবং delete করুন।</p>
            </div>
            <button className="admin-primary-button" type="button" onClick={openCreate}>
              ＋ নতুন Admin
            </button>
          </div>

          <div className="admin-admin-summary">
            <span>মোট Admin <strong>{admins.length}</strong></span>
            <span>Active <strong>{activeAdminCount}</strong></span>
            <span>আপনার role <strong>{roleLabel[me?.role || "admin"]}</strong></span>
          </div>

          {adminsLoading ? (
            <div className="admin-list-empty">Admin list load হচ্ছে...</div>
          ) : admins.length === 0 ? (
            <div className="admin-list-empty">কোনো admin account পাওয়া যায়নি।</div>
          ) : (
            <div className="admin-admin-list">
              {admins.map((admin) => (
                <article className="admin-admin-item" key={admin.id}>
                  <div className="admin-admin-avatar">
                    {admin.avatar_path ? (
                      <img src={admin.avatar_path} alt={admin.name} />
                    ) : (
                      <span>{initials(admin.name)}</span>
                    )}
                  </div>
                  <div className="admin-admin-info">
                    <div className="admin-admin-title">
                      <strong>{admin.name}</strong>
                      <span className={`admin-role-badge ${admin.role}`}>
                        {roleLabel[admin.role]}
                      </span>
                      <span className={`admin-status-badge ${admin.is_active ? "active" : "inactive"}`}>
                        {admin.is_active ? "Active" : "Inactive"}
                      </span>
                    </div>
                    <p>{admin.email}</p>
                    <small>{admin.phone || "Phone number নেই"}</small>
                  </div>
                  <div className="admin-admin-actions">
                    <button type="button" onClick={() => openEdit(admin)}>Edit</button>
                    <button
                      className="danger"
                      type="button"
                      disabled={admin.id === me?.id}
                      onClick={() => deleteAdmin(admin)}
                    >
                      Delete
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      )}

      {!isSuperAdmin && (
        <div className="admin-form-card admin-access-note">
          <span>🔒</span>
          <div>
            <strong>Admin account management</strong>
            <p>শুধু Super Admin অন্য Admin account তৈরি ও পরিচালনা করতে পারবেন।</p>
          </div>
        </div>
      )}

      {modalOpen && (
        <div className="admin-modal-backdrop" role="presentation" onMouseDown={(e) => {
          if (e.target === e.currentTarget) setModalOpen(false);
        }}>
          <form className="admin-modal admin-admin-modal" onSubmit={saveAdmin}>
            <button
              className="admin-modal-close"
              type="button"
              aria-label="বন্ধ করুন"
              onClick={() => setModalOpen(false)}
            >
              ×
            </button>

            <span className="admin-kicker">ADMIN ACCOUNT</span>
            <h2>{editingAdmin ? "Admin Edit করুন" : "নতুন Admin তৈরি করুন"}</h2>

            <div className="admin-form-grid">
              <label>
                নাম *
                <input
                  value={adminForm.name}
                  onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })}
                  required
                />
              </label>
              <label>
                Phone
                <input
                  type="tel"
                  value={adminForm.phone}
                  onChange={(e) => setAdminForm({ ...adminForm, phone: e.target.value })}
                />
              </label>
              <label className="full">
                Email *
                <input
                  type="email"
                  value={adminForm.email}
                  onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })}
                  required
                />
              </label>

              {!editingAdmin && (
                <label className="full">
                  Password *
                  <input
                    type="password"
                    minLength={8}
                    autoComplete="new-password"
                    value={adminForm.password}
                    onChange={(e) => setAdminForm({ ...adminForm, password: e.target.value })}
                    placeholder="কমপক্ষে 8 characters"
                    required
                  />
                </label>
              )}

              <label className="full">
                Profile Image
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(e) =>
                    setAdminForm({ ...adminForm, avatar: e.target.files?.[0] || null, remove_avatar: false })
                  }
                />
                <small className="admin-field-help">JPG / PNG / WEBP · সর্বোচ্চ 3MB</small>
              </label>

              {editingAdmin?.avatar_path && (
                <label className="admin-checkbox-field full admin-settings-checkbox">
                  <input
                    type="checkbox"
                    checked={adminForm.remove_avatar}
                    onChange={(e) => setAdminForm({ ...adminForm, remove_avatar: e.target.checked, avatar: null })}
                  />
                  <span>বর্তমান profile image সরান</span>
                </label>
              )}

              <label>
                Role
                <select
                  value={adminForm.role}
                  onChange={(e) =>
                    setAdminForm({
                      ...adminForm,
                      role: e.target.value as AdminUser["role"],
                    })
                  }
                >
                  <option value="admin">Admin</option>
                  <option value="super_admin">Super Admin</option>
                </select>
              </label>

              <label className="admin-checkbox-field admin-settings-checkbox">
                <input
                  type="checkbox"
                  checked={adminForm.is_active}
                  onChange={(e) => setAdminForm({ ...adminForm, is_active: e.target.checked })}
                />
                <span>Account Active</span>
              </label>
            </div>

            <div className="admin-form-actions">
              <button className="admin-secondary-button" type="button" onClick={() => setModalOpen(false)}>
                বাতিল
              </button>
              <button className="admin-primary-button" type="submit">
                {editingAdmin ? "পরিবর্তন Save করুন" : "Admin তৈরি করুন"}
              </button>
            </div>
          </form>
        </div>
      )}
    </section>
  );
}
