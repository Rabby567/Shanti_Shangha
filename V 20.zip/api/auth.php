<?php
/**
 * Admin authentication and own-account API.
 *
 * POST /api/auth.php?action=login
 * POST /api/auth.php?action=logout
 * GET  /api/auth.php?action=me
 * POST /api/auth.php?action=profile
 * POST /api/auth.php?action=password
 */

require_once __DIR__ . '/helpers.php';
allow_cors();

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    send_json(['success' => false, 'message' => 'Server configuration is missing.'], 503);
}

$config = require $configFile;
$sessionName = $config['app']['session_name'] ?? 'shanti_sangha_admin';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name($sessionName);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

$action = $_GET['action'] ?? 'me';

try {
    require_once __DIR__ . '/db.php';
    $pdo = db();

    if ($action === 'me' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        if (empty($_SESSION['admin_id'])) {
            send_json(['success' => true, 'authenticated' => false]);
        }

        $statement = $pdo->prepare(
            'SELECT id, name, email, phone, avatar_path, role, is_active, last_login_at, created_at, updated_at
             FROM admins WHERE id = :id LIMIT 1'
        );
        $statement->execute(['id' => (int) $_SESSION['admin_id']]);
        $admin = $statement->fetch();

        if (!$admin || !(int) $admin['is_active']) {
            $_SESSION = [];
            session_destroy();
            send_json(['success' => true, 'authenticated' => false]);
        }

        send_json([
            'success' => true,
            'authenticated' => true,
            'admin' => [
                'id' => (int) $admin['id'],
                'name' => (string) $admin['name'],
                'email' => (string) $admin['email'],
                'phone' => (string) ($admin['phone'] ?? ''),
                'avatar_path' => $admin['avatar_path'] ? (string) $admin['avatar_path'] : null,
                'role' => (string) $admin['role'],
                'is_active' => (bool) $admin['is_active'],
                'last_login_at' => $admin['last_login_at'],
                'created_at' => $admin['created_at'],
                'updated_at' => $admin['updated_at'],
            ],
        ]);
    }

    if ($action === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], '', $params['secure'], $params['httponly']);
        }

        session_destroy();
        send_json(['success' => true, 'message' => 'Logged out successfully.']);
    }

    if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $payload = json_decode(file_get_contents('php://input'), true);
        $email = strtolower(trim((string) ($payload['email'] ?? '')));
        $password = (string) ($payload['password'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            send_json(['success' => false, 'message' => 'ইমেইল এবং পাসওয়ার্ড সঠিকভাবে দিন।'], 422);
        }

        $statement = $pdo->prepare(
            'SELECT id, name, email, phone, avatar_path, password_hash, role, is_active
             FROM admins WHERE email = :email LIMIT 1'
        );
        $statement->execute(['email' => $email]);
        $admin = $statement->fetch();

        if (!$admin || !(int) $admin['is_active'] || !password_verify($password, $admin['password_hash'])) {
            send_json(['success' => false, 'message' => 'ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।'], 401);
        }

        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        $_SESSION['admin_email'] = $admin['email'];
        $_SESSION['admin_role'] = $admin['role'];

        $update = $pdo->prepare('UPDATE admins SET last_login_at = NOW() WHERE id = :id');
        $update->execute(['id' => $admin['id']]);

        send_json([
            'success' => true,
            'authenticated' => true,
            'admin' => [
                'id' => (int) $admin['id'],
                'name' => (string) $admin['name'],
                'email' => (string) $admin['email'],
                'phone' => (string) ($admin['phone'] ?? ''),
                'avatar_path' => $admin['avatar_path'] ? (string) $admin['avatar_path'] : null,
                'role' => (string) $admin['role'],
            ],
        ]);
    }

    if ($action === 'profile' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $adminId = require_admin_session();

        $name = trim((string) ($_POST['name'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $removeAvatar = ($_POST['remove_avatar'] ?? '0') === '1';

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            send_json(['success' => false, 'message' => 'নাম এবং valid email দিন।'], 422);
        }

        $statement = $pdo->prepare('SELECT avatar_path FROM admins WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $adminId]);
        $current = $statement->fetch();

        if (!$current) {
            send_json(['success' => false, 'message' => 'Admin account পাওয়া যায়নি।'], 404);
        }

        $duplicate = $pdo->prepare('SELECT id FROM admins WHERE email = :email AND id <> :id LIMIT 1');
        $duplicate->execute(['email' => $email, 'id' => $adminId]);
        if ($duplicate->fetch()) {
            send_json(['success' => false, 'message' => 'এই email অন্য একজন admin ব্যবহার করছেন।'], 409);
        }

        $avatarPath = $current['avatar_path'] ?? null;
        $newAvatar = null;

        if (isset($_FILES['avatar']) && (int) $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE) {
            $newAvatar = save_admin_avatar($_FILES['avatar']);
            $avatarPath = $newAvatar;
        } elseif ($removeAvatar) {
            $avatarPath = null;
        }

        $update = $pdo->prepare(
            'UPDATE admins SET name = :name, email = :email, phone = :phone, avatar_path = :avatar_path WHERE id = :id'
        );
        $update->execute([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'avatar_path' => $avatarPath,
            'id' => $adminId,
        ]);

        if ($newAvatar || ($removeAvatar && $current['avatar_path'])) {
            delete_uploaded_file($current['avatar_path'] ?? null);
        }

        $_SESSION['admin_name'] = $name;
        $_SESSION['admin_email'] = $email;

        $fresh = $pdo->prepare(
            'SELECT id, name, email, phone, avatar_path, role, is_active, last_login_at, created_at, updated_at
             FROM admins WHERE id = :id LIMIT 1'
        );
        $fresh->execute(['id' => $adminId]);
        $admin = $fresh->fetch();

        send_json([
            'success' => true,
            'message' => 'Profile সফলভাবে আপডেট হয়েছে।',
            'admin' => [
                'id' => (int) $admin['id'],
                'name' => (string) $admin['name'],
                'email' => (string) $admin['email'],
                'phone' => (string) ($admin['phone'] ?? ''),
                'avatar_path' => $admin['avatar_path'] ? (string) $admin['avatar_path'] : null,
                'role' => (string) $admin['role'],
                'is_active' => (bool) $admin['is_active'],
                'last_login_at' => $admin['last_login_at'],
                'created_at' => $admin['created_at'],
                'updated_at' => $admin['updated_at'],
            ],
        ]);
    }

    if ($action === 'password' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $adminId = require_admin_session();
        $payload = json_decode(file_get_contents('php://input'), true);

        $currentPassword = (string) ($payload['current_password'] ?? '');
        $newPassword = (string) ($payload['new_password'] ?? '');

        if ($currentPassword === '' || mb_strlen($newPassword) < 8) {
            send_json(['success' => false, 'message' => 'Current password দিন এবং নতুন password কমপক্ষে 8 characters রাখুন।'], 422);
        }

        $statement = $pdo->prepare('SELECT password_hash FROM admins WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $adminId]);
        $admin = $statement->fetch();

        if (!$admin || !password_verify($currentPassword, $admin['password_hash'])) {
            send_json(['success' => false, 'message' => 'Current password সঠিক নয়।'], 401);
        }

        $update = $pdo->prepare('UPDATE admins SET password_hash = :password_hash WHERE id = :id');
        $update->execute([
            'password_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
            'id' => $adminId,
        ]);

        send_json(['success' => true, 'message' => 'Password সফলভাবে পরিবর্তন হয়েছে।']);
    }

    send_json(['success' => false, 'message' => 'Invalid authentication request.'], 405);
} catch (PDOException $error) {
    if ((int) ($error->errorInfo[1] ?? 0) === 1062) {
        send_json(['success' => false, 'message' => 'এই email আগে থেকেই ব্যবহার হচ্ছে।'], 409);
    }
    send_json(['success' => false, 'message' => 'সার্ভারে একটি সমস্যা হয়েছে।'], 503);
} catch (Throwable $error) {
    send_json(['success' => false, 'message' => 'সার্ভারে একটি সমস্যা হয়েছে।'], 503);
}
