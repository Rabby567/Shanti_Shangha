# Shanti Sangha

React/Vite public website with a cPanel-compatible PHP + MySQL backend foundation.

## Architecture

- **React + Vite** — public website and Admin Dashboard UI
- **PHP + PDO** — backend API for cPanel hosting
- **MySQL/MariaDB** — application database
- **`/uploads/`** — images and videos stored on the same hosting account

## Backend setup (cPanel)

1. Create a MySQL database and database user from cPanel.
2. Import `database/schema.sql` using phpMyAdmin.
3. Copy `api/config.example.php` to `api/config.php`.
4. Add the cPanel database name, user, password, and production URL.
5. Keep `api/config.php` out of GitHub; it is already ignored by `.gitignore`.
6. The future API modules will live under `api/` and use the shared PDO connection.

## Upload storage

The `uploads/` directory is reserved for production media. Gallery images and videos will be uploaded there through the PHP API, while MySQL stores only their file paths and metadata.

## Important

The current milestone adds the admin authentication foundation. The PHP API uses secure password hashing and an HttpOnly session cookie; the one-time create-admin utility must be deleted from the production server after the first admin is created. CRUD modules will be added module-by-module so each part can be tested independently.


## V12 — MySQL Dashboard Connection

Step 3 adds `api/dashboard.php`, a session-protected PHP endpoint that reads live counts from MySQL. The Admin Dashboard fetches these values after login.

### cPanel setup
1. Create a MySQL database and database user in cPanel.
2. Open phpMyAdmin and import `database/schema.sql`.
3. Copy `api/config.example.php` to `api/config.php`.
4. Put the cPanel database name, username and password in `api/config.php`.
5. Set a long random `setup_token`.
6. Use `api/create-admin.php` once to create the first admin, then delete that file from the server.
7. Keep `api/config.php` out of GitHub.

The Vite development server cannot execute PHP by itself. The live MySQL API will work when the project is served through PHP on cPanel (or another PHP-capable local server).
