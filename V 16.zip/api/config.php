<?php

return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'shanti_sangha',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
    ],

    'app' => [
        'url' => 'http://localhost/shanti-sangha',
        'session_name' => 'shanti_sangha_admin',
        'setup_token' => 'ShantiSanghaSetup2026_ChangeMe_938472'
    ],
];