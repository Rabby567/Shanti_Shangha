<?php
/**
 * Small reusable HTTP helpers for the PHP API.
 */

function send_json(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function allow_cors(): void
{
    // The public site and API will normally share the same origin on cPanel.
    // Keep CORS restrictive when a separate development origin is required.
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $configFile = __DIR__ . '/config.php';

    if ($origin !== '' && is_file($configFile)) {
        $config = require $configFile;
        $allowed = rtrim($config['app']['url'] ?? '', '/');

        if ($allowed !== '' && rtrim($origin, '/') === $allowed) {
            header("Access-Control-Allow-Origin: {$origin}");
            header('Vary: Origin');
        }
    }

    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}
