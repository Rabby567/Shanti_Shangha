<?php
/**
 * Admin authentication API.
 *
 * Supported actions:
 *   POST /api/auth.php?action=login
 *   POST /api/auth.php?action=logout
 *   GET  /api/auth.php?action=me
 */

require_once __DIR__ . '/helpers.php';
allow_cors();

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    send_json(['success' => false, 'message' => 'Server configuration is missing.'], 503);
}

$config = require $configFile;
$sessionName = $config['app']['session_name'] ?? 'shanti_sangha_admin';

session_name($sessionName);
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

$action = $_GET['action'] ?? 'me';

if ($action === 'me') {
    if (empty($_SESSION['admin_id'])) {
        send_json(['success' => true, 'authenticated' => false]);
    }

    send_json([
        'success' => true,
        'authenticated' => true,
        'admin' => [
            'id' => (int) $_SESSION['admin_id'],
            'name' => $_SESSION['admin_name'],
            'email' => $_SESSION['admin_email'],
            'role' => $_SESSION['admin_role'],
        ],
    ]);
}

if ($action === 'logout') {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], '', $params['secure'], $params['httponly']);
    }

    session_destroy();
    send_json(['success' => true, 'message' => 'Logged out successfully.']);
}

if ($action !== 'login' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json(['success' => false, 'message' => 'Invalid authentication request.'], 405);
}

$payload = json_decode(file_get_contents('php://input'), true);
$email = trim((string) ($payload['email'] ?? ''));
$password = (string) ($payload['password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    send_json(['success' => false, 'message' => 'ইমেইল এবং পাসওয়ার্ড সঠিকভাবে দিন।'], 422);
}

try {
    require_once __DIR__ . '/db.php';

    $statement = db()->prepare(
        'SELECT id, name, email, password_hash, role, is_active
         FROM admins
         WHERE email = :email
         LIMIT 1'
    );
    $statement->execute(['email' => $email]);
    $admin = $statement->fetch();

    // Use the same generic response for unknown/inactive users and wrong passwords.
    if (!$admin || !(int) $admin['is_active'] || !password_verify($password, $admin['password_hash'])) {
        send_json(['success' => false, 'message' => 'ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।'], 401);
    }

    session_regenerate_id(true);
    $_SESSION['admin_id'] = (int) $admin['id'];
    $_SESSION['admin_name'] = $admin['name'];
    $_SESSION['admin_email'] = $admin['email'];
    $_SESSION['admin_role'] = $admin['role'];

    $update = db()->prepare('UPDATE admins SET last_login_at = NOW() WHERE id = :id');
    $update->execute(['id' => $admin['id']]);

    send_json([
        'success' => true,
        'authenticated' => true,
        'admin' => [
            'id' => (int) $admin['id'],
            'name' => $admin['name'],
            'email' => $admin['email'],
            'role' => $admin['role'],
        ],
    ]);
} catch (Throwable $error) {
    send_json(['success' => false, 'message' => 'সার্ভারে একটি সমস্যা হয়েছে।'], 503);
}
